using Microsoft.Xna.Framework;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace Memebound.Items
{
	public class yes : ModItem
	{
		public override void SetStaticDefaults() {
			Tooltip.SetDefault("gay");
		}

		public override void SetDefaults() {
			item.width = 500;
			item.height = 257;
			item.value = 100;
			item.rare = ItemRarityID.Blue;
		}
	}
}