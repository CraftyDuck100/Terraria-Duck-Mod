using Terraria.ModLoader;

namespace Memebound
{
	class Memebound : Mod
	{
		public Memebound()
		{
		}
	}
}
