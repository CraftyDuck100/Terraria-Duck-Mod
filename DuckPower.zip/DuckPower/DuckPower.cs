using Terraria.ModLoader;

namespace DuckPower
{
	class DuckPower : Mod
	{
		public DuckPower()
		{
		}
	}
}
